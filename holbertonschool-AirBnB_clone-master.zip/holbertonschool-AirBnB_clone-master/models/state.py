#!/usr/bin/python3
from models.base_model import BaseModel

"""This is a class with a public
class attributes"""


class State(BaseModel):
    """State class"""

    name = str()
